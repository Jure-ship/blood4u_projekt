package com.example.b4u;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.ImageView;

import com.example.b4u.model.bolnice;
import com.example.b4u.recycleview.BolnicaAdapter;

import java.util.ArrayList;
import java.util.List;

public class guest_activty extends AppCompatActivity {
    private ImageView otvori_meni;
    final Context context = this;
    Button prijava;
    Dialog myDialog1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest_activty);


        otvori_meni = findViewById(R.id.image_meni);
        prijava=findViewById(R.id.button_prijava);

        /* WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(myDialog1.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.MATCH_PARENT; */
        myDialog1 = new Dialog(context);
        myDialog1.setContentView(R.layout.pop_out_guest);

        prijava.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(guest_activty.this,LogIn.class);
                startActivity(intent);

                }

        });
        otvori_meni.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog1.show();
            }
        });
/*
        rvmojeBolnice1 = (RecyclerView) findViewById(R.id.recyclemenu_guest);
        setUserInfo();
        setAdapter();
    }
        private void setAdapter() {
        setOnclickListener();
        BolnicaAdapter adapter=new BolnicaAdapter(rcbolnice);
        RecyclerView.LayoutManager bolnicaAdapter = new LinearLayoutManager(getApplicationContext());
        rvmojeBolnice1.setLayoutManager(bolnicaAdapter);
        rvmojeBolnice1.setItemAnimator(new DefaultItemAnimator());
        rvmojeBolnice1.setAdapter(adapter);
    }

    private void setOnclickListener() {
        listener=ne
    }

    private void setUserInfo() {
        rcbolnice=new ArrayList<>();
        rcbolnice.add(new bolnice(R.drawable.bolnica_krizine,"Državna bolnica Krizine",55 ,"Otvoreno: 9:00 - 21:00"));
        rcbolnice.add(new bolnice(R.drawable.bolnica_firule,"Državna bolnica Firule",45,"Otvoreno: 9:00 - 21:00" ));
        rcbolnice.add(new bolnice(R.drawable.ambulantamertoajk,"Ambulanta mertojak",23,"Otvoreno: 9:00 - 21:00" ));
        rcbolnice.add(new bolnice(R.drawable.domzdravlja,"Dom zdravlja Split",14,"Otvoreno: 9:00 - 21:00" ));
    }*/


    }
}

