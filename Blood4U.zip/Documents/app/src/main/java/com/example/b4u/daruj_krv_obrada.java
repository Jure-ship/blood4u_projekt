package com.example.b4u;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;

public class daruj_krv_obrada extends AppCompatActivity {
        Button txtfile,potvrd,unaz;
        CheckBox cb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daruj_krv_obrada);

    //    ((AppCompatActivity) this).getSupportActionBar().hide();

        txtfile=findViewById(R.id.textfile);
        potvrd=findViewById(R.id.potvrujem22);
        cb=findViewById(R.id.checkBox_ck);
        unaz=findViewById(R.id.unazad);

        unaz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent10=new Intent(daruj_krv_obrada.this,all_phone1.class);
                startActivity(intent10);
            }
        });
        txtfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent7=new Intent(daruj_krv_obrada.this,popout_potvrda.class);
                startActivity(intent7);
            }
        });
        cb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cb.isChecked()) {
                    potvrd.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent9 = new Intent(daruj_krv_obrada.this, donacija_order.class);
                            startActivity(intent9);
                        }
                    });
                }
                else {
                    cb.setVisibility(View.VISIBLE);
                }
            }
        });


    }
}