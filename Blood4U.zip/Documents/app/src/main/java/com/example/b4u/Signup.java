package com.example.b4u;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.vishnusivadas.advanced_httpurlconnection.PutData;

public class Signup extends AppCompatActivity  {
    EditText etfullname, etusername, etemail, etpassword, ponovnalozinka, datumrodtxt;
    Button btnsignup;
    ProgressBar progres;
    Spinner mySpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registracija_korisnika);

        etfullname = findViewById(R.id.unosime);  //koristimo ovo
        etusername = findViewById(R.id.unos_prezime); //koristimo ovo
        etemail = findViewById(R.id.mail_unos); //koristimo ovo
        etpassword = findViewById(R.id.šifra); //koristimo ovo
        btnsignup = findViewById(R.id.potvrda_registracije);
        progres=findViewById(R.id.progress);

        mySpinner=(Spinner) findViewById(R.id.spinner_moj);



        btnsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fullname,username,password,email;
                fullname=String.valueOf(etfullname.getText());
                username=String.valueOf(etusername.getText());
                password=String.valueOf(etpassword.getText());
                email=String.valueOf(etemail.getText());

                if (!fullname.equals("")&& !username.equals("")&& !password.equals("")&& !email.equals("")) {
                    progres.setVisibility(View.VISIBLE);
                    //Start ProgressBar first (Set visibility VISIBLE)
                    Handler handler = new Handler();
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            //Starting Write and Read data with URL
                            //Creating array for parameters
                            String[] field = new String[4];
                            field[0] = "fullname";
                            field[1] = "username";
                            field[2] = "password";
                            field[3] = "email";
                            //Creating array for data
                            String[] data = new String[4];
                            data[0] = fullname;
                            data[1] = username;
                            data[2] = password;
                            data[3] = email;
                            PutData putData = new PutData("http://192.168.1.8/LoginRegister/signup.php?_ijt=4q4ndqs68n1sl9kj2a8d780h6m", "POST", field, data);
                            if (putData.startPut()) {
                                if (putData.onComplete()) {
                                    progres.setVisibility(View.GONE);
                                    String result = putData.getResult();
                                    if (result.equals("Sign Up Success")) {
                                        Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
                                        Intent intent=new Intent(getApplicationContext(),LogIn.class);
                                            startActivity(intent);
                                            finish();
                                    }
                                    else {
                                        Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
                                    }
                                    //End ProgressBar (Set visibility to GONE)
                                }
                            }
                            //End Write and Read data with URL
                        }
                    });
                }
                else {
                    Toast.makeText(getApplicationContext(),"All fields are required!",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}

