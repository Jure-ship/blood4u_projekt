package com.example.b4u.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.example.b4u.R;


public class Profile_ragment extends Fragment {
    ImageView closesec;
    LinearLayout data_obavijseti;
    Animation left;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_profile_ragment,container,false);
        closesec=(ImageView)view.findViewById(R.id.close_data_forobav);
        data_obavijseti=(LinearLayout)view.findViewById(R.id.obavijesti);
        left =(Animation) AnimationUtils.loadAnimation(getActivity(), R.anim.anime_left);
        closesec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                data_obavijseti.startAnimation(left);
                    data_obavijseti.removeAllViews();
                    data_obavijseti.setVisibility(View.GONE);

            }
        });
        return view;
    }
}
