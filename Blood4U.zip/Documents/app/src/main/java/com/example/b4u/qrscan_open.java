package com.example.b4u;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import com.example.b4u.fragments.Settings_Fragment;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;

import java.util.Timer;
import java.util.TimerTask;

public class qrscan_open extends AppCompatActivity {


    ProgressBar pgbar;
    Button dnrjkrv;
    ImageView zatvori_pop;
    int counter=59;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrscan_open);

        pgbar=findViewById(R.id.pogbar_pop);
        dnrjkrv=findViewById(R.id.button_drjkrv);
        zatvori_pop=findViewById(R.id.zatv12);

        pgbar.getProgressDrawable().setColorFilter(
                Color.RED, android.graphics.PorterDuff.Mode.SRC_IN);

        final Timer t=new Timer();
        TimerTask tt= new TimerTask() {
            @Override
            public void run() {
                counter=counter+5;
                pgbar.setProgress(counter);

            }
        };
        t.schedule(tt,35,1000);

        TimerTask tt1=new TimerTask() {
            @Override
            public void run() {
                counter=counter-4;
                pgbar.setProgress(counter);

            }
        };
        t.schedule(tt1,34,700);
        dnrjkrv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent5 = new Intent(qrscan_open.this, daruj_krv_obrada.class);
                startActivity(intent5);
            }
        });

        zatvori_pop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent6 = new Intent(qrscan_open.this, all_phone1.class);
                startActivity(intent6);
            }
        });
    }
}